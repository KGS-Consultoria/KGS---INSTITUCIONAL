import React from 'react';
import { Toaster } from '@/components/ui/toaster.jsx';
import { TooltipProvider } from '@/components/ui/tooltip.jsx';
import KgsHeroSection from '@/components/sections/KgsHeroSection';
import KgsAboutSection from '@/components/sections/KgsAboutSection';
import KgsMissionVisionValuesSection from '@/components/sections/KgsMissionVisionValuesSection';
import KgsPniHighlightSection from '@/components/sections/KgsPniHighlightSection';
import KgsDifferentiatorsSection from '@/components/sections/KgsDifferentiatorsSection';
import KgsWhatWeDeliverSection from '@/components/sections/KgsWhatWeDeliverSection';
import KgsDetailedServicesSection from '@/components/sections/KgsDetailedServicesSection';
import KgsGainsSection from '@/components/sections/KgsGainsSection';
import KgsPartnershipsSection from '@/components/sections/KgsPartnershipsSection';
import KgsClosingSection from '@/components/sections/KgsClosingSection';
import KgsFooter from '@/components/sections/KgsFooter';


const kgsLogoUrl = "https://storage.googleapis.com/hostinger-horizons-assets-prod/7040f89c-9a6d-458f-a45c-cf1bfcbf8dc8/03961c97532202f54e46c5f93cc60ccf.jpg";
const pniLogoUrl = "https://storage.googleapis.com/hostinger-horizons-assets-prod/7040f89c-9a6d-458f-a45c-cf1bfcbf8dc8/29505cc3bf1f6e4026966b00924763ed.jpg";


function App() {
  return (
    <TooltipProvider>
      <div className="flex flex-col min-h-screen bg-background font-sans">
        <Toaster />
        <main className="flex-grow">
          <KgsHeroSection logoUrl={kgsLogoUrl} />
          <KgsAboutSection />
          <KgsMissionVisionValuesSection />
          <KgsPniHighlightSection pniLogoUrl={pniLogoUrl} />
          <KgsDifferentiatorsSection />
          <KgsWhatWeDeliverSection />
          <KgsDetailedServicesSection />
          <KgsGainsSection />
          <KgsPartnershipsSection pniLogo={pniLogoUrl} />
          <KgsClosingSection />
        </main>
        <KgsFooter logoUrl={kgsLogoUrl} />
      </div>
    </TooltipProvider>
  );
}

export default App;
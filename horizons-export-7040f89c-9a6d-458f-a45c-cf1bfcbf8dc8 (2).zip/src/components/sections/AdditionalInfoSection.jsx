
import React from 'react';
import SectionWrapper from './SectionWrapper';
import SectionTitle from './SectionTitle';
import Card from './Card';
import { MapPin, Target, CheckSquare } from 'lucide-react';

const AdditionalInfoSection = () => (
  <SectionWrapper className="bg-background py-12 md:py-20">
    <div className="container mx-auto max-w-5xl">
      <SectionTitle>KGS é Manutenção com Propósito, Tecnologia e Resultado</SectionTitle>
      <div className="grid md:grid-cols-3 gap-8">
        <Card
          icon={<MapPin size={32} />}
          title="Atuação Nacional"
          description="Com equipe técnica experiente para atender sua empresa onde ela estiver."
          className="h-full"
        />
        <Card
          icon={<Target size={32} />}
          title="Projetos Personalizados"
          description="Adaptados para diferentes segmentos e necessidades específicas."
          className="h-full"
        />
        <Card
          icon={<CheckSquare size={32} />}
          title="Execução Assistida e Suporte"
          description="Foco no campo, nos resultados, com diagnóstico, implantação e suporte contínuo."
          className="h-full"
        />
      </div>
    </div>
  </SectionWrapper>
);

export default AdditionalInfoSection;
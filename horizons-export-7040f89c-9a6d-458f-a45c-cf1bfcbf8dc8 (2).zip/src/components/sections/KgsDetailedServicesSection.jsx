import React from 'react';
import SectionWrapper from './SectionWrapper';
import { motion } from 'framer-motion';
import { Dialog, DialogTrigger, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog.jsx';
import { Button } from '@/components/ui/button.jsx';
import { SlidersHorizontal, Zap, Users, BarChart3, ExternalLink, Lightbulb, ShieldCheck, TrendingUp, Brain, AlertTriangle, Wind, Droplets, DatabaseZap, Settings2 } from 'lucide-react';

const KgsSectionTitle = ({ children, className = "" }) => (
  <h2 className={`text-3xl md:text-4xl font-bold kgs-text-dark-blue mb-12 section-title-underline ${className}`}>
    {children}
  </h2>
);

const ServiceItem = ({ icon, title, shortDescription, children, index, crmLink = null }) => (
  <Dialog>
    <DialogTrigger asChild>
      <motion.div
        className="bg-card p-6 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer border border-border hover:border-primary flex flex-col items-start text-left h-full"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5, delay: index * 0.1 }}
      >
        <div className="flex items-center mb-4">
          {React.cloneElement(icon, { className: "w-10 h-10 text-primary mr-4" })}
          <h3 className="text-xl font-semibold kgs-text-dark-blue">{title}</h3>
        </div>
        <p className="text-gray-600 text-sm mb-4 flex-grow">{shortDescription}</p>
        <Button variant="outline" className="mt-auto kgs-text-light-blue border-primary hover:bg-primary/10 w-full">
          Ver Detalhes
        </Button>
      </motion.div>
    </DialogTrigger>
    <DialogContent className="sm:max-w-3xl bg-white p-6 md:p-8 max-h-[90vh] overflow-y-auto">
      <DialogHeader>
        <DialogTitle className="text-2xl text-primary flex items-center">
          {React.cloneElement(icon, { className: "w-7 h-7 mr-3" })}
          {title}
        </DialogTitle>
      </DialogHeader>
      <DialogDescription className="mt-4 text-gray-700 space-y-4 text-base">
        {children}
        {crmLink && (
          <div className="mt-6">
            <Button asChild className="bg-primary hover:bg-primary/90">
              <a href={crmLink} target="_blank" rel="noopener noreferrer">
                Indicação KGS para CRM <ExternalLink size={16} className="ml-2" />
              </a>
            </Button>
          </div>
        )}
      </DialogDescription>
    </DialogContent>
  </Dialog>
);

const AcusticoCmsContent = () => (
  <>
    <p>O Acústico CMS KGS, em parceria com a tecnologia Ecometric/Sonoline, é uma solução de vanguarda para monitoramento preditivo. Utiliza sensores acústicos e inteligência artificial para emular o ouvido humano ("sentinela virtual"), detectando com precisão eventos de ruído e falhas mecânicas em estágios iniciais, permitindo gerenciamento antecipado e redução do tempo de inatividade.</p>

    <div className="my-4 grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
      <div>
        <h4 className="font-semibold text-md text-primary-dark mt-4 mb-2 flex items-center"><Brain size={20} className="mr-2" />Tecnologia e Inteligência Artificial</h4>
        <ul className="list-disc list-inside space-y-1 pl-4 text-sm">
          <li>Monitoramento contínuo e online de ruídos.</li>
          <li>Detecção automática de anomalias e tipos de ruído.</li>
          <li>Quantificação de eventos e comunicação com plataforma SaaS.</li>
          <li>Alertas, relatórios e gravação de áudio com detecções.</li>
        </ul>
      </div>
      <div className="flex justify-center">
        <img  alt="Ecometric Sonoline Sensor" className="rounded-lg shadow-md max-h-48" src="https://images.unsplash.com/photo-1663057270471-8653f9a57f18" />
      </div>
    </div>
    
    <h4 className="font-semibold text-md text-primary-dark mt-6 mb-2">Aplicações Chave e Benefícios:</h4>
    
    <div className="space-y-3">
      <div className="p-3 bg-sky-50 rounded-md">
        <h5 className="font-medium text-sky-700 flex items-center"><Zap size={18} className="mr-2" />Subestações e Distribuição de Energia</h5>
        <p className="text-sm text-sky-600">Detecção de descargas parciais, conexões deficientes, problemas em isoladores. <strong>Benefícios:</strong> Prevenção de blecautes, segurança, redução de perdas.</p>
      </div>
      <div className="p-3 bg-green-50 rounded-md">
        <h5 className="font-medium text-green-700 flex items-center"><Droplets size={18} className="mr-2" />Centrais de Geração (Hidrelétricas, PCHs)</h5>
        <p className="text-sm text-green-600">Monitoramento de geradores, turbinas, comportas. Detecção de cavitação, desalinhamentos. <strong>Benefícios:</strong> Eficiência energética, extensão da vida útil, segurança.</p>
      </div>
      <div className="p-3 bg-teal-50 rounded-md">
        <h5 className="font-medium text-teal-700 flex items-center"><Wind size={18} className="mr-2" />Parques Eólicos (AeroInsight)</h5>
        <p className="text-sm text-teal-600">IA treinada para tipos de ruído específicos de turbinas, detecção automática em cada áudio. <strong>Benefícios:</strong> Gestão operacional otimizada, relatórios automáticos.</p>
      </div>
       <div className="p-3 bg-amber-50 rounded-md">
        <h5 className="font-medium text-amber-700 flex items-center"><AlertTriangle size={18} className="mr-2" />Equipamentos Mecânicos Rotativos</h5>
        <p className="text-sm text-amber-600">Falhas em rolamentos, problemas de lubrificação, desbalanceamento. <strong>Benefícios:</strong> Redução de quebras, programação de intervenções.</p>
      </div>
    </div>

    <p className="mt-4">Com o Acústico CMS KGS e Ecometric, sua manutenção se torna proativa, baseada em dados reais, evitando paradas custosas e perigosas, e otimizando a gestão de ativos.</p>
    <div className="mt-4 flex justify-center">
        <img  alt="Ecometric AeroInsight Dashboard" className="rounded-lg shadow-md max-h-60" src="https://images.unsplash.com/photo-1688389785532-59480efcd308" />
    </div>
  </>
);

const CmsKgsContent = () => (
  <>
    <p>O CMS KGS é o nosso software de gestão de manutenção (CMMS) desenvolvido internamente, focado na simplicidade, usabilidade e resultados práticos para o chão de fábrica. Ele é projetado para ser uma ferramenta intuitiva que capacita as equipes de manutenção a gerenciar suas atividades de forma eficiente.</p>
    
    <h4 className="font-semibold text-md text-primary-dark mt-4 mb-2">Principais Funcionalidades:</h4>
    <ul className="list-disc list-inside space-y-1 pl-4">
      <li>Cadastro e Gestão de Ativos: organize informações detalhadas sobre seus equipamentos.</li>
      <li>Planejamento e Controle de Ordens de Serviço: crie, atribua, acompanhe e finalize OS de forma digital.</li>
      <li>Manutenção Preventiva e Preditiva: agende planos de manutenção baseados em calendário, horímetro ou condições.</li>
      <li>Gestão de Sobressalentes: controle básico de peças e materiais necessários para as manutenções.</li>
      <li>Apontamento de Horas e Custos: registre o tempo gasto e os custos associados a cada OS.</li>
      <li>Relatórios Gerenciais Simplificados: acompanhe indicadores chave como backlog, tempo de execução e conformidade de planos.</li>
      <li>Interface Amigável e Acessível: projetado para ser fácil de usar por toda a equipe, do técnico ao gestor.</li>
    </ul>

    <h4 className="font-semibold text-md text-primary-dark mt-4 mb-2">Benefícios do CMS KGS:</h4>
    <div className="grid md:grid-cols-2 gap-4 mt-2">
      <div className="bg-sky-50 p-3 rounded-md">
        <h5 className="font-medium text-sky-700 flex items-center"><Settings2 size={18} className="mr-2" />Organização e Padronização</h5>
        <p className="text-sm text-sky-600">Centralize as informações da manutenção e padronize seus processos.</p>
      </div>
      <div className="bg-green-50 p-3 rounded-md">
        <h5 className="font-medium text-green-700 flex items-center"><TrendingUp size={18} className="mr-2" />Melhoria na Tomada de Decisão</h5>
        <p className="text-sm text-green-600">Dados confiáveis para embasar decisões estratégicas e otimizar recursos.</p>
      </div>
      <div className="bg-amber-50 p-3 rounded-md">
        <h5 className="font-medium text-amber-700 flex items-center"><BarChart3 size={18} className="mr-2" />Aumento da Eficiência</h5>
        <p className="text-sm text-amber-600">Reduza o tempo gasto em tarefas administrativas e foque na execução.</p>
      </div>
      <div className="bg-indigo-50 p-3 rounded-md">
        <h5 className="font-medium text-indigo-700 flex items-center"><Lightbulb size={18} className="mr-2" />Foco no Essencial</h5>
        <p className="text-sm text-indigo-600">Uma ferramenta sem complexidades desnecessárias, focada no que realmente importa para a gestão da manutenção.</p>
      </div>
    </div>
    <p className="mt-3">O CMS KGS é oferecido como parte de nossas soluções de consultoria e implementação, ajudando sua empresa a dar o primeiro passo rumo a uma gestão de manutenção mais inteligente e digitalizada.</p>
  </>
);


const KgsDetailedServicesSection = () => {
  const services = [
    {
      icon: <SlidersHorizontal />,
      title: "Sistema de Gestão de Manutenção (SGM)",
      shortDescription: "Otimize suas rotinas de manutenção, reduza custos e aumente a confiabilidade dos seus ativos com um SGM personalizado.",
      content: (
        <>
          <p>Um Sistema de Gestão de Manutenção (SGM), também conhecido como CMMS (Computerized Maintenance Management System), é uma ferramenta essencial para qualquer indústria que busca excelência operacional. Ele centraliza informações, automatiza processos e fornece dados cruciais para a tomada de decisão estratégica.</p>
          
          <h4 className="font-semibold text-md text-primary-dark mt-4 mb-2">Aplicações Principais:</h4>
          <ul className="list-disc list-inside space-y-1 pl-4">
            <li>Controle de Ordens de Serviço (OS): criação, atribuição, acompanhamento e histórico.</li>
            <li>Gestão de Ativos: cadastro detalhado de equipamentos, histórico de intervenções, custos.</li>
            <li>Manutenção Preventiva: agendamento automático de inspeções e tarefas baseadas em calendário ou uso.</li>
            <li>Manutenção Preditiva: integração com sensores e análise de dados para prever falhas.</li>
            <li>Gestão de Estoque de Peças: controle de inventário, requisição e otimização de compras.</li>
            <li>Relatórios e KPIs: indicadores de desempenho como MTBF, MTTR, backlog, custos, etc.</li>
          </ul>

          <h4 className="font-semibold text-md text-primary-dark mt-4 mb-2">Ganhos e Benefícios com a Implantação da Manutenção Preventiva (facilitada pelo SGM):</h4>
          <div className="grid md:grid-cols-2 gap-4 mt-2">
            <div className="bg-sky-50 p-3 rounded-md">
              <h5 className="font-medium text-sky-700 flex items-center"><TrendingUp size={18} className="mr-2" />Aumento da Disponibilidade</h5>
              <p className="text-sm text-sky-600">Redução de paradas não programadas e aumento do tempo de máquina produzindo.</p>
            </div>
            <div className="bg-green-50 p-3 rounded-md">
              <h5 className="font-medium text-green-700 flex items-center"><ShieldCheck size={18} className="mr-2" />Maior Confiabilidade</h5>
              <p className="text-sm text-green-600">Equipamentos mais confiáveis, com menor incidência de falhas inesperadas.</p>
            </div>
            <div className="bg-amber-50 p-3 rounded-md">
              <h5 className="font-medium text-amber-700 flex items-center"><BarChart3 size={18} className="mr-2" />Redução de Custos</h5>
              <p className="text-sm text-amber-600">Diminuição de gastos com reparos emergenciais, horas extras e perdas de produção.</p>
            </div>
            <div className="bg-indigo-50 p-3 rounded-md">
              <h5 className="font-medium text-indigo-700 flex items-center"><Lightbulb size={18} className="mr-2" />Otimização de Recursos</h5>
              <p className="text-sm text-indigo-600">Melhor planejamento da mão de obra e uso mais eficiente de peças e materiais.</p>
            </div>
          </div>
          <p className="mt-3">A KGS auxilia na escolha, implantação e personalização do SGM ideal para sua operação, garantindo que você extraia o máximo valor da ferramenta.</p>
        </>
      )
    },
    {
      icon: <Zap />,
      title: "Acústico CMS KGS (Monitoramento Preditivo)",
      shortDescription: "Detecte falhas em equipamentos elétricos e mecânicos de forma antecipada através da análise de emissões acústicas e ultrassônicas com IA.",
      content: <AcusticoCmsContent />
    },
    {
      icon: <DatabaseZap />,
      title: "CMS KGS (Software de Gestão)",
      shortDescription: "Nosso software de gestão de manutenção (CMMS) focado na simplicidade e resultados práticos para o chão de fábrica.",
      content: <CmsKgsContent />
    },
    {
      icon: <Users />,
      title: "Sistema CRM (Gestão de Relacionamento com Cliente)",
      shortDescription: "Fortaleça o relacionamento com seus clientes e otimize seus processos de vendas e pós-vendas com uma plataforma CRM eficiente.",
      crmLink: "https://forms.ploomes.com/form/d3170916a96c49db8d509e76ee5e54dc",
      content: (
        <>
          <p>Um Sistema CRM (Customer Relationship Management) é fundamental para empresas que desejam gerenciar e analisar as interações com clientes atuais e potenciais. Ele ajuda a otimizar processos, melhorar a satisfação do cliente e impulsionar as vendas.</p>
          
          <h4 className="font-semibold text-md text-primary-dark mt-4 mb-2">Aplicações e Funcionalidades Comuns:</h4>
          <ul className="list-disc list-inside space-y-1 pl-4">
            <li>Gestão de Contatos e Leads: centralização de informações de clientes e prospects.</li>
            <li>Funil de Vendas: acompanhamento de oportunidades em cada estágio do processo de venda.</li>
            <li>Automação de Marketing e Vendas: e-mails automáticos, follow-ups, segmentação de clientes.</li>
            <li>Atendimento ao Cliente: registro de interações, histórico de suporte, gestão de tickets.</li>
            <li>Relatórios e Análises: visão completa do desempenho de vendas, comportamento do cliente e eficácia das campanhas.</li>
          </ul>

          <h4 className="font-semibold text-md text-primary-dark mt-4 mb-2">Ganhos com a Implementação de um CRM:</h4>
           <div className="grid md:grid-cols-2 gap-4 mt-2">
            <div className="bg-teal-50 p-3 rounded-md">
              <h5 className="font-medium text-teal-700 flex items-center"><TrendingUp size={18} className="mr-2" />Melhora no Relacionamento</h5>
              <p className="text-sm text-teal-600">Comunicação personalizada e maior entendimento das necessidades do cliente.</p>
            </div>
            <div className="bg-lime-50 p-3 rounded-md">
              <h5 className="font-medium text-lime-700 flex items-center"><BarChart3 size={18} className="mr-2" />Aumento da Produtividade</h5>
              <p className="text-sm text-lime-600">Automatização de tarefas repetitivas e processos de vendas mais eficientes.</p>
            </div>
            <div className="bg-fuchsia-50 p-3 rounded-md">
              <h5 className="font-medium text-fuchsia-700 flex items-center"><ShieldCheck size={18} className="mr-2" />Retenção de Clientes</h5>
              <p className="text-sm text-fuchsia-600">Maior satisfação e lealdade, resultando em menor churn.</p>
            </div>
            <div className="bg-orange-50 p-3 rounded-md">
              <h5 className="font-medium text-orange-700 flex items-center"><Lightbulb size={18} className="mr-2" />Decisões Baseadas em Dados</h5>
              <p className="text-sm text-orange-600">Visão clara do funil de vendas e performance para estratégias mais assertivas.</p>
            </div>
          </div>
          <p className="mt-3">A KGS recomenda e auxilia na integração de sistemas CRM como o Ploomes, uma plataforma robusta e flexível que pode transformar a gestão comercial da sua empresa. Utilize nosso link de indicação para conhecer!</p>
        </>
      )
    }
  ];

  return (
    <SectionWrapper className="bg-background py-12 md:py-20" id="kgs-detailed-services">
      <div className="container mx-auto max-w-6xl">
        <KgsSectionTitle className="text-center">Nossas Soluções em Detalhe</KgsSectionTitle>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <ServiceItem
              key={index}
              icon={service.icon}
              title={service.title}
              shortDescription={service.shortDescription}
              index={index}
              crmLink={service.crmLink}
            >
              {service.content}
            </ServiceItem>
          ))}
        </div>
      </div>
    </SectionWrapper>
  );
};

export default KgsDetailedServicesSection;
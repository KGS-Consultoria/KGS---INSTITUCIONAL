
import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';

const HeroSection = ({ logoUrl }) => (
  <div className="min-h-screen flex flex-col justify-center items-center text-center bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800 text-white p-4">
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
    >
      <img  alt="KGS Consultoria Logo" className="h-24 mx-auto mb-8" src={logoUrl} />
      <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
        KGS Consultoria
        <br />
        <span className="bg-clip-text text-transparent bg-gradient-to-r from-sky-400 to-cyan-300">
          A Manutenção Inteligente que Transforma Resultados
        </span>
      </h1>
      <p className="text-lg md:text-xl text-slate-300 max-w-2xl mx-auto mb-10">
        Elevamos sua gestão de manutenção a um novo patamar com tecnologia, inovação e foco em resultados práticos.
      </p>
      <Button size="lg" className="bg-sky-500 hover:bg-sky-600 text-white" onClick={() => document.getElementById('contact-section')?.scrollIntoView({ behavior: 'smooth' })}>
        Descubra Como
      </Button>
    </motion.div>
  </div>
);

export default HeroSection;
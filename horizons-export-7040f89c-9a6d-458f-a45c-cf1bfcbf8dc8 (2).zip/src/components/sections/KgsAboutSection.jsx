import React from 'react';
import SectionWrapper from './SectionWrapper';
import { motion } from 'framer-motion';

const KgsSectionTitle = ({ children, className = "" }) => (
  <h2 className={`text-3xl md:text-4xl font-bold kgs-text-dark-blue mb-6 section-title-underline ${className}`}>
    {children}
  </h2>
);

const KgsAboutSection = () => (
  <SectionWrapper className="bg-background py-12 md:py-20">
    <div className="container mx-auto max-w-4xl text-left">
      <KgsSectionTitle>Sobre a KGS</KgsSectionTitle>
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="space-y-4 text-lg text-gray-700 leading-relaxed"
      >
        <p>
          A KGS surgiu de uma inquietação profunda: por que a manutenção industrial ainda é tratada como um mal necessário, quando pode — e deve — ser o motor da produtividade, da inovação e da confiabilidade?
        </p>
        <p>
          Criada por quem vive o chão de fábrica, a KGS acredita que tecnologia só faz sentido quando é simples, acessível e transforma o dia a dia das equipes. Por isso, não vendemos promessas: entregamos processos. Não ficamos na teoria: atuamos lado a lado, na prática. Acreditamos no poder da manutenção inteligente — estratégica, preditiva e orientada por dados.
        </p>
        <p>
          Nossa atuação combina conhecimento técnico sólido com sensibilidade para processos, pessoas e cultura organizacional. Apoiamos as empresas com treinamentos certificados, suporte técnico contínuo e soluções que nascem da escuta e da vivência real dos desafios da operação.
        </p>
        <p>
          Mais do que resolver falhas, a KGS promove uma mudança de mentalidade. Ensinamos times a enxergar além do imediato, assumir o controle do seu processo e elevar o padrão do que é possível. Porque quando a manutenção deixa de ser um custo e passa a ser um ativo estratégico, toda a empresa muda de patamar.
        </p>
        <p className="font-semibold kgs-text-dark-blue">
          Transformar a manutenção é só o começo. O que a gente faz, no fim das contas, é transformar o jeito como a indústria pensa, age e cresce.
        </p>
      </motion.div>
    </div>
  </SectionWrapper>
);

export default KgsAboutSection;
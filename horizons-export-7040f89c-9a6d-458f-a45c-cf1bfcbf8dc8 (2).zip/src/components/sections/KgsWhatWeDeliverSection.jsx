import React from 'react';
import SectionWrapper from './SectionWrapper';
import { motion } from 'framer-motion';
import { Dialog, DialogTrigger, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog.jsx';
import { Brain, Award, Activity, UserCheck, TrendingUp, CheckSquare, Wrench, BarChart2, BookOpen } from 'lucide-react';

const KgsSectionTitle = ({ children, className = "" }) => (
  <h2 className={`text-3xl md:text-4xl font-bold kgs-text-dark-blue mb-10 section-title-underline ${className}`}>
    {children}
  </h2>
);

const deliverableItems = [
  { 
    id: "processes", 
    icon: <Brain />, 
    text: "Processos inteligentes e personalizados", 
    description: "Soluções alinhadas à operação para maior eficiência e menos retrabalho.",
    tip: "Reavalie seus processos periodicamente para identificar e corrigir pontos de melhoria." 
  },
  { 
    id: "training", 
    icon: <Award />, 
    text: "Treinamentos práticos e certificados", 
    description: "Equipes preparadas para atuar com excelência e reduzir erros.",
    tip: "Estimule a troca de experiências entre os times para fortalecer o aprendizado."
  },
  { 
    id: "monitoring", 
    icon: <Activity />, 
    text: "Monitoramento e análise de dados", 
    description: "Transformamos dados em ações que antecipam problemas.",
    tip: "Use os dados para criar planos proativos, evitando surpresas e paradas."
  },
  { 
    id: "support", 
    icon: <UserCheck />, 
    text: "Suporte técnico contínuo", 
    description: "Acompanhamento constante para garantir que tudo funcione na prática.",
    tip: "Mantenha canais abertos para feedback e ajustes rápidos."
  },
  { 
    id: "culture", 
    icon: <TrendingUp />, 
    text: "Cultura de melhoria contínua", 
    description: "Equipes engajadas buscando evolução constante.",
    tip: "Reconheça e celebre pequenas conquistas para manter a motivação e o foco."
  },
  { 
    id: "diag", 
    icon: <CheckSquare />, 
    text: "Diagnóstico técnico completo", 
    description: "Análise aprofundada da situação atual da manutenção e identificação de oportunidades.",
    tip: "Um bom diagnóstico é o primeiro passo para um plano de manutenção eficaz."
  },
  { 
    id: "cms", 
    icon: <BookOpen />, 
    text: "Implantação do CMS", 
    description: "Configuração e treinamento para uso do nosso sistema de gestão de manutenção gratuito.",
    tip: "Utilize o CMS para registrar todas as atividades e criar um histórico valioso dos ativos."
  },
  { 
    id: "tpm", 
    icon: <Wrench />, 
    text: "Plano estratégico de TPM e manutenção autônoma", 
    description: "Desenvolvimento e implementação de estratégias de Manutenção Produtiva Total e Autônoma.",
    tip: "Envolver os operadores na manutenção autônoma aumenta o senso de propriedade e a detecção precoce de falhas."
  },
  { 
    id: "kpi", 
    icon: <BarChart2 />, 
    text: "Indicadores e metas", 
    description: "Definição e acompanhamento de KPIs para monitorar a performance da manutenção.",
    tip: "Escolha indicadores que realmente reflitam os objetivos da sua manutenção e revise-os periodicamente."
  },
];

const DeliverableItem = ({ icon, text, description, tip, id, index }) => (
  <Dialog>
    <DialogTrigger asChild>
      <motion.div
        className="flex items-center p-4 mb-3 bg-gray-50 rounded-lg shadow-sm hover:bg-primary-foreground hover:shadow-md transition-all duration-300 cursor-pointer border border-transparent hover:border-primary/50 group"
        initial={{ opacity: 0, x: -20 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.3, delay: index * 0.05 }}
      >
        {React.cloneElement(icon, { className: "w-7 h-7 text-primary mr-4 flex-shrink-0" })}
        <span className="text-gray-800 group-hover:text-primary-dark transition-colors duration-300 font-medium">{text}</span>
      </motion.div>
    </DialogTrigger>
    <DialogContent className="sm:max-w-lg bg-white">
      <DialogHeader>
        <DialogTitle className="text-primary flex items-center text-xl">
          {React.cloneElement(icon, { className: "w-6 h-6 mr-3" })}
          {text}
        </DialogTitle>
      </DialogHeader>
      <div className="mt-4 space-y-3">
        <p className="text-foreground text-base">{description}</p>
        <div className="bg-primary/10 p-3 rounded-md">
            <p className="text-sm text-primary-dark"><span className="font-semibold">Dica de Aplicação:</span> {tip}</p>
        </div>
      </div>
    </DialogContent>
  </Dialog>
);

const KgsWhatWeDeliverSection = () => (
  <SectionWrapper className="bg-background py-12 md:py-20">
    <div className="container mx-auto max-w-4xl">
      <KgsSectionTitle className="text-center">O Que Entregamos</KgsSectionTitle>
      <div className="grid md:grid-cols-2 gap-x-8 gap-y-1">
        {deliverableItems.map((item, index) => (
          <DeliverableItem 
            key={item.id}
            id={item.id}
            icon={item.icon}
            text={item.text}
            description={item.description}
            tip={item.tip}
            index={index}
          />
        ))}
      </div>
    </div>
  </SectionWrapper>
);

export default KgsWhatWeDeliverSection;
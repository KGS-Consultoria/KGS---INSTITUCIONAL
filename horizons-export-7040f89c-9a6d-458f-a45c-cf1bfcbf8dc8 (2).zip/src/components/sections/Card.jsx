
import React from 'react';
import { motion } from 'framer-motion';

const Card = ({ icon, title, description, className = '', items, titleClassName = '', descriptionClassName = '' }) => (
  <motion.div 
    className={`bg-card p-6 rounded-lg shadow-lg border border-border hover:shadow-xl transition-shadow duration-300 flex flex-col ${className}`}
    whileHover={{ y: -5 }}
  >
    {icon && (
      <div className="flex items-center text-primary mb-4">
        {icon}
        {title && <h3 className={`text-xl font-semibold ml-3 ${titleClassName}`}>{title}</h3>}
      </div>
    )}
    {!icon && title && <h3 className={`text-2xl font-semibold mb-3 text-primary ${titleClassName}`}>{title}</h3>}
    {description && <p className={`text-muted-foreground ${descriptionClassName}`}>{description}</p>}
    {items && (
      <ul className="list-disc list-inside text-muted-foreground space-y-1 mt-2">
        {items.map((item, index) => (
          <li key={index}>{item}</li>
        ))}
      </ul>
    )}
  </motion.div>
);

export default Card;
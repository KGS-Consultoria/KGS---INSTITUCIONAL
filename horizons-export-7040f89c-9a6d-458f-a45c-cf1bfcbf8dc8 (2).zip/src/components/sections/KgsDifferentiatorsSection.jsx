import React from 'react';
import SectionWrapper from './SectionWrapper';
import { motion } from 'framer-motion';
import { Dialog, DialogTrigger, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Lightbulb, Users, CheckCircle, Target, ShieldCheck, Info } from 'lucide-react';

const KgsSectionTitle = ({ children, className = "" }) => (
  <h2 className={`text-3xl md:text-4xl font-bold kgs-text-dark-blue mb-10 section-title-underline ${className}`}>
    {children}
  </h2>
);

const DifferentiatorItem = ({ icon, title, description, curiosity, index }) => (
  <motion.div 
    className="bg-card p-6 rounded-lg shadow-lg border border-border flex flex-col items-start h-full"
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ duration: 0.5, delay: index * 0.1 }}
  >
    <div className="flex items-center mb-3">
      {React.cloneElement(icon, { className: "w-10 h-10 text-primary mr-3" })}
      <h3 className="text-xl font-semibold kgs-text-dark-blue">{title}</h3>
    </div>
    <p className="text-gray-600 text-sm mb-4 flex-grow">{description}</p>
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="kgs-text-light-blue border-primary hover:bg-primary/10 mt-auto">
          <Info size={16} className="mr-2" /> Curiosidade
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md bg-white">
        <DialogHeader>
          <DialogTitle className="text-primary flex items-center">
            {React.cloneElement(icon, { className: "w-6 h-6 mr-2" })}
            {title}
          </DialogTitle>
        </DialogHeader>
        <DialogDescription className="mt-4 text-gray-700 text-base">
          <span className="font-semibold">Você sabia?</span> {curiosity}
        </DialogDescription>
      </DialogContent>
    </Dialog>
  </motion.div>
);

const differentiatorsData = [
  {
    icon: <Lightbulb />,
    title: "Tecnologia com propósito",
    description: "Inovação que funciona no chão de fábrica.",
    curiosity: "Muitas falhas começam com pequenos sinais que passam despercebidos — a tecnologia certa capta esses detalhes antes que eles virem problema."
  },
  {
    icon: <Users />,
    title: "Foco na equipe",
    description: "Investir em pessoas é mover a transformação.",
    curiosity: "Equipes capacitadas e engajadas antecipam problemas e agem com mais autonomia."
  },
  {
    icon: <CheckCircle />,
    title: "Ação prática",
    description: "Nada de teoria vazia — estamos juntos em cada passo, garantindo resultados reais.",
    curiosity: "A presença constante no chão de fábrica ajuda a destravar processos que pareciam imutáveis."
  },
  {
    icon: <Target />,
    title: "Mentalidade estratégica",
    description: "Ensinar a pensar além do imediato e criar cultura de melhoria contínua.",
    curiosity: "Mudanças culturais sustentam o sucesso no longo prazo, mesmo que levem tempo para acontecer."
  },
  {
    icon: <ShieldCheck />,
    title: "Suporte 360º",
    description: "Treinamentos, consultoria, implementação e acompanhamento para a jornada completa.",
    curiosity: "Suporte contínuo evita que pequenos deslizes se tornem grandes problemas."
  }
];

const KgsDifferentiatorsSection = () => (
  <SectionWrapper className="bg-secondary py-12 md:py-20">
    <div className="container mx-auto max-w-6xl">
      <KgsSectionTitle className="text-center">Nossos Diferenciais</KgsSectionTitle>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {differentiatorsData.map((item, index) => (
          <DifferentiatorItem 
            key={index}
            icon={item.icon}
            title={item.title}
            description={item.description}
            curiosity={item.curiosity}
            index={index}
          />
        ))}
      </div>
    </div>
  </SectionWrapper>
);

export default KgsDifferentiatorsSection;
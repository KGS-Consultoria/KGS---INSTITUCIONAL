import React from 'react';
import SectionWrapper from './SectionWrapper';
import { motion } from 'framer-motion';
import { Target, Eye, Gem, CheckCircle } from 'lucide-react'; // Gem for Values, CheckCircle for list items

const KgsSectionTitle = ({ children, className = "" }) => (
  <h2 className={`text-3xl md:text-4xl font-bold kgs-text-dark-blue mb-4 section-title-underline ${className}`}>
    {children}
  </h2>
);

const ValueItem = ({ text }) => (
  <motion.li 
    className="flex items-center text-gray-700 mb-1"
    initial={{ opacity: 0, x: -20 }}
    whileInView={{ opacity: 1, x: 0 }}
    viewport={{ once: true }}
    transition={{ duration: 0.3 }}
  >
    <CheckCircle className="w-5 h-5 text-primary mr-2 flex-shrink-0" />
    {text}
  </motion.li>
);

const KgsMissionVisionValuesSection = () => {
  const values = ["Ética", "Inovação", "Parceria", "Respeito", "Compromisso", "Qualidade", "Sustentabilidade", "Foco no Cliente"]; // Example values based on typical corporate values

  return (
    <SectionWrapper className="bg-secondary py-12 md:py-20">
      <div className="container mx-auto max-w-4xl">
        <div className="grid md:grid-cols-3 gap-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <div className="flex items-center mb-3">
              <Target className="w-8 h-8 text-primary mr-3" />
              <h3 className="text-2xl font-semibold kgs-text-dark-blue">Missão</h3>
            </div>
            <p className="text-gray-700 leading-relaxed">
              Consultoria técnica com soluções práticas, inteligentes e acessíveis que melhorem organização e resultado.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="flex items-center mb-3">
              <Eye className="w-8 h-8 text-primary mr-3" />
              <h3 className="text-2xl font-semibold kgs-text-dark-blue">Visão</h3>
            </div>
            <p className="text-gray-700 leading-relaxed">
              Ser referência em manutenção inteligente, com tecnologia, cultura e suporte técnico.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <div className="flex items-center mb-3">
              <Gem className="w-8 h-8 text-primary mr-3" />
              <h3 className="text-2xl font-semibold kgs-text-dark-blue">Valores</h3>
            </div>
            <ul className="grid grid-cols-2 gap-x-4">
              {values.map((value, index) => (
                <ValueItem key={index} text={value} />
              ))}
            </ul>
          </motion.div>
        </div>
      </div>
    </SectionWrapper>
  );
};

export default KgsMissionVisionValuesSection;
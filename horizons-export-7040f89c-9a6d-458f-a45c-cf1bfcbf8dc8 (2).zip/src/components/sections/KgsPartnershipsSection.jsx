import React from 'react';
import SectionWrapper from './SectionWrapper';
import { motion } from 'framer-motion';
import { ExternalLink } from 'lucide-react';


const KgsSectionTitle = ({ children, className = "" }) => (
  <h2 className={`text-3xl md:text-4xl font-bold kgs-text-dark-blue mb-12 section-title-underline ${className}`}>
    {children}
  </h2>
);

const PartnerLogo = ({ children, name, href, index }) => {
  return (
    <motion.a 
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="flex flex-col justify-center items-center text-center p-4 bg-gray-50 rounded-lg shadow-sm h-44 hover:shadow-md transition-shadow group"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <div className="h-20 flex items-center justify-center mb-2">
          {children}
      </div>
      <p className="text-sm text-muted-foreground font-medium group-hover:text-primary transition-colors">{name}</p>
      <ExternalLink size={14} className="text-gray-400 group-hover:text-primary transition-colors mt-1 opacity-0 group-hover:opacity-100" />
    </motion.a>
  );
};


const KgsPartnershipsSection = ({ pniLogo }) => {
  const partners = [
    { 
      name: "ECOMETRIC (Sensor de IA)", 
      logoUrl: "https://storage.googleapis.com/hostinger-horizons-assets-prod/7040f89c-9a6d-458f-a45c-cf1bfcbf8dc8/bd295fee24ab614c21f9b75ad4416b88.jpg",
      href: "https://www.ecometric.com.br/"
    },
    { 
      name: "Portal Nacional da Indústria (PNI)", 
      logoUrl: pniLogo,
      href: "https://www.portalnacionaldaindustria.com.br/",
    },
    { 
      name: "Ploomes CRM", 
      logoUrl: "https://storage.googleapis.com/hostinger-horizons-assets-prod/7040f89c-9a6d-458f-a45c-cf1bfcbf8dc8/00689e690bfef440c920f350d97d0cc2.jpg",
      href: "https://www.ploomes.com/" 
    },
  ];


  return (
    <SectionWrapper className="bg-secondary py-12 md:py-20">
      <div className="container mx-auto max-w-5xl">
        <KgsSectionTitle className="text-center">Nossos Parceiros Fundamentais</KgsSectionTitle>
        
        <div className="grid grid-cols-2 md:grid-cols-3 gap-6 md:gap-8">
          {partners.map((partner, index) => (
            <PartnerLogo key={partner.name} name={partner.name} href={partner.href} index={index}>
                <img alt={`${partner.name} Logo`} src={partner.logoUrl} className="max-h-16 object-contain transition-all duration-300" />
            </PartnerLogo>
          ))}
        </div>
      </div>
    </SectionWrapper>
  );
};

export default KgsPartnershipsSection;
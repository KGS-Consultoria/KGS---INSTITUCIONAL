
import React from 'react';
import { Button } from '@/components/ui/button';
import SectionWrapper from './SectionWrapper';

const CtaSection = () => (
  <SectionWrapper id="contact-section" className="bg-gradient-to-r from-blue-700 to-sky-600 text-white py-16 md:py-24">
    <div className="container mx-auto max-w-3xl text-center">
      <h2 className="text-3xl md:text-4xl font-bold mb-6">Quer revolucionar a gestão de manutenção da sua indústria?</h2>
      <p className="text-lg md:text-xl mb-10 max-w-2xl mx-auto">
        Fale com a KGS e descubra como transformar processos em lucro, tecnologia em rotina e manutenção em performance.
      </p>
      <Button 
        size="lg" 
        variant="secondary" 
        className="bg-white text-blue-700 hover:bg-slate-100 font-semibold px-10 py-3"
        onClick={() => {
            const footer = document.getElementById('kgs-footer');
            if (footer) {
              footer.scrollIntoView({ behavior: 'smooth' });
            } else {
              window.location.href = 'mailto:contato@kgsmanutencao.com.br';
            }
          }}
      >
        Fale com a KGS
      </Button>
    </div>
  </SectionWrapper>
);

export default CtaSection;
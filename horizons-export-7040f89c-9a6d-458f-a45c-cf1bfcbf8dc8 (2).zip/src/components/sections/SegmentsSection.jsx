
import React from 'react';
import SectionWrapper from './SectionWrapper';
import SectionTitle from './SectionTitle';
import Card from './Card';
import { Factory, Zap, Network } from 'lucide-react';

const SegmentsSection = () => (
  <SectionWrapper className="bg-secondary py-12 md:py-20">
    <div className="container mx-auto max-w-5xl">
      <SectionTitle>Aplicação por Segmento</SectionTitle>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        <Card
          icon={<Factory size={32} />}
          title="Pequenas e Médias Indústrias"
          description="Soluções escaláveis para otimizar a manutenção em diversos setores industriais, aumentando a produtividade e reduzindo custos."
          className="h-full"
        />
        <Card
          icon={<Zap size={32} />}
          title="PCHs (Pequenas Centrais Hidrelétricas)"
          description="Gestão especializada para PCHs, focando na confiabilidade dos ativos e na maximização da geração de energia."
          className="h-full"
        />
        <Card
          icon={<Network size={32} />}
          title="Subestações de Energia"
          description="Manutenção preditiva e preventiva para subestações, garantindo a segurança e a continuidade do fornecimento de energia."
          className="h-full"
        />
        <Card
          icon={<Network size={32} />}
          title="Redes de Energia"
          description="Consultoria para otimização da manutenção em redes de distribuição e transmissão, melhorando a eficiência e a resiliência do sistema."
          className="h-full"
        />
      </div>
    </div>
  </SectionWrapper>
);

export default SegmentsSection;
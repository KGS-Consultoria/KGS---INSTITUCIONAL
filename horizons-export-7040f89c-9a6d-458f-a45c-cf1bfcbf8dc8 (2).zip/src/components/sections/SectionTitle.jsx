
import React from 'react';

const SectionTitle = ({ children, className = '' }) => (
  <h2 className={`text-3xl md:text-4xl font-bold mb-8 md:mb-12 text-center text-primary ${className}`}>
    {children}
  </h2>
);

export default SectionTitle;
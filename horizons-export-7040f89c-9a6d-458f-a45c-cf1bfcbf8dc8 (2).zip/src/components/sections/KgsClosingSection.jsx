import React from 'react';
import SectionWrapper from './SectionWrapper';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button'; // Assuming you have a Button component

const KgsClosingSection = () => (
  <SectionWrapper className="kgs-bg-dark py-16 md:py-24 text-center">
    <div className="container mx-auto max-w-3xl">
      <motion.h2 
        className="text-3xl md:text-4xl font-semibold kgs-text-white mb-8 leading-tight"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
      >
        Tenha em sua empresa uma gestão inteligente e eficiente de manutenção — e transforme tecnologia em resultado.
      </motion.h2>
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6, delay: 0.2 }}
      >
        <Button 
          size="lg" 
          className="bg-primary hover:bg-primary/90 kgs-text-white font-semibold px-10 py-3"
          onClick={() => {
            const footer = document.getElementById('kgs-footer');
            if (footer) {
              footer.scrollIntoView({ behavior: 'smooth' });
            } else {
              window.location.href = 'mailto:contato@kgsmanutencao.com.br';
            }
          }}
        >
          Fale Conosco
        </Button>
      </motion.div>
    </div>
  </SectionWrapper>
);

export default KgsClosingSection;
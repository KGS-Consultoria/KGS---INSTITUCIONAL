import React from 'react';
import { Instagram, Linkedin, MessageSquare as WhatsApp, Mail, Phone, Globe } from 'lucide-react';

const KgsFooter = ({ logoUrl }) => (
  <footer className="bg-primary-dark text-primary-dark-foreground py-10 md:py-16" id="contato">
    <div className="container mx-auto max-w-5xl px-4">
      <div className="grid md:grid-cols-3 gap-10 items-center">
        <div className="flex justify-center md:justify-start">
          <img alt="KGS Consultoria Logo" src={logoUrl} className="h-16 md:h-20 filter brightness-0 invert" />
        </div>
        
        <div className="text-center md:text-left space-y-3">
          <h3 className="text-xl font-semibold text-primary mb-2">Entre em Contato</h3>
          <a href="mailto:contato@kgsmanutencao.com.br" className="flex items-center justify-center md:justify-start text-gray-300 hover:text-primary transition-colors group">
            <Mail size={18} className="mr-3 text-primary group-hover:text-sky-300 transition-colors" />
            contato@kgsmanutencao.com.br
          </a>
          <a href="tel:+5547999424871" className="flex items-center justify-center md:justify-start text-gray-300 hover:text-primary transition-colors group">
            <Phone size={18} className="mr-3 text-primary group-hover:text-sky-300 transition-colors" />
            (47) 9 9942-4871
          </a>
           <a href="https://kgsmanutencao.com.br/" target="_blank" rel="noopener noreferrer" className="flex items-center justify-center md:justify-start text-gray-300 hover:text-primary transition-colors group">
            <Globe size={18} className="mr-3 text-primary group-hover:text-sky-300 transition-colors" />
            www.kgsmanutencao.com.br
          </a>
        </div>

        <div className="flex flex-col items-center md:items-end">
            <h3 className="text-xl font-semibold text-primary mb-3">Conecte-se Conosco</h3>
            <div className="flex space-x-5">
            <a href="https://www.instagram.com/kgs_manutencao?igsh=MWtnZmQ4dHIwcm5scA%3D%3D&utm_source=qr" target="_blank" rel="noopener noreferrer" aria-label="Instagram KGS" className="text-gray-200 hover:text-primary transition-transform duration-300 hover:scale-110">
                <Instagram size={30} />
            </a>
            <a href="https://www.linkedin.com/company/kgs-inteligência-em-gestão-de-manutenção/" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn KGS" className="text-gray-200 hover:text-primary transition-transform duration-300 hover:scale-110">
                <Linkedin size={30} />
            </a>
            <a href="https://wa.me/5547999424871?text=Olá!%20Gostaria%20de%20saber%20mais%20sobre%20a%20KGS%20Consultoria." target="_blank" rel="noopener noreferrer" aria-label="WhatsApp KGS" className="text-gray-200 hover:text-primary transition-transform duration-300 hover:scale-110">
                <WhatsApp size={30} />
            </a>
            </div>
        </div>
      </div>
      <div className="text-center text-sm text-gray-400 mt-12 pt-8 border-t border-gray-700">
        <p>&copy; {new Date().getFullYear()} KGS Consultoria em Gestão Inteligente de Manutenção.</p>
        <p>Todos os direitos reservados. CNPJ: XX.XXX.XXX/0001-XX</p>
      </div>
    </div>
  </footer>
);

export default KgsFooter;

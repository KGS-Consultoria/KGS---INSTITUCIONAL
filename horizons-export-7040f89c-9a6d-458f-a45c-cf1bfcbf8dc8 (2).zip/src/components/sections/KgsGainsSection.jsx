import React from 'react';
import SectionWrapper from './SectionWrapper';
import { motion } from 'framer-motion';
import { TrendingDown, Zap, PackageCheck, Users, Brain, ArrowUpCircle } from 'lucide-react';

const KgsSectionTitle = ({ children, className = "" }) => (
  <h2 className={`text-3xl md:text-4xl font-bold kgs-text-dark-blue mb-10 section-title-underline ${className}`}>
    {children}
  </h2>
);

const gainItems = [
  { icon: <TrendingDown />, text: "Redução de custos e falhas" },
  { icon: <ArrowUpCircle />, text: "Aumento da disponibilidade de máquinas" },
  { icon: <PackageCheck />, text: "Melhoria nos processos e controle de estoque" },
  { icon: <Users />, text: "Qualificação da equipe" },
  { icon: <Brain />, text: "Tomada de decisão mais rápida com base em indicadores" },
];

const GainItem = ({ icon, text, index }) => (
  <motion.div 
    className="flex items-center p-4 bg-card rounded-lg shadow-sm border border-border"
    initial={{ opacity: 0, scale: 0.9 }}
    whileInView={{ opacity: 1, scale: 1 }}
    viewport={{ once: true }}
    transition={{ duration: 0.4, delay: index * 0.1 }}
  >
    {React.cloneElement(icon, { className: "w-8 h-8 text-primary mr-4 flex-shrink-0" })}
    <span className="text-lg text-gray-700">{text}</span>
  </motion.div>
);

const KgsGainsSection = () => (
  <SectionWrapper className="bg-background py-12 md:py-20">
    <div className="container mx-auto max-w-3xl">
      <KgsSectionTitle className="text-center">Ganhos para Sua Empresa</KgsSectionTitle>
      <div className="space-y-6">
        {gainItems.map((item, index) => (
          <GainItem 
            key={index}
            icon={item.icon}
            text={item.text}
            index={index}
          />
        ))}
      </div>
    </div>
  </SectionWrapper>
);

export default KgsGainsSection;
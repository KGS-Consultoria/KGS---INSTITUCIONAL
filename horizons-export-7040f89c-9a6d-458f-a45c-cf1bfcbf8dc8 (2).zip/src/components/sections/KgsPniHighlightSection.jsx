import React from 'react';
import SectionWrapper from './SectionWrapper';
import { motion } from 'framer-motion';
import { Dialog, DialogTrigger, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog.jsx';
import { Button } from '@/components/ui/button.jsx';
import { ExternalLink, Info } from 'lucide-react';

const KgsPniHighlightSection = ({ pniLogoUrl }) => {
  const PniDetailedContent = () => (
    <>
      <p className="mb-3">O PNI (Portal Nacional da Indústria) é uma plataforma estratégica que oferece visibilidade, conexão e oportunidades de negócios para empresas que buscam se destacar no mercado nacional e internacional. Ao integrar o PNI, sua empresa ganha uma vitrine de alta relevância, conectando-se a um público qualificado e ampliando suas possibilidades de crescimento.</p>
      <h4 className="font-semibold text-md md:text-lg text-primary-dark mt-4 mb-2">Destaque para Empresas Inovadoras como a KGS - Inteligência em Gestão de Manutenção</h4>
      <p className="mb-3">Empresas que investem em inovação, como a KGS, que atua na área de gestão de manutenção, encontram no PNI uma ferramenta poderosa para consolidar sua presença e fortalecer sua marca. A plataforma garante:</p>
      <ol className="list-decimal list-inside space-y-2 mb-3 text-sm md:text-base">
        <li><strong>Visibilidade Garantida para Sua Empresa:</strong> Ao cadastrar sua empresa no PNI, você coloca seu negócio à frente de um público altamente qualificado, com mais de 1,5 milhão de pesquisas mensais. Seus diferenciais, produtos e serviços ganham destaque, aumentando sua presença digital e fortalecendo sua marca frente a potenciais clientes e parceiros.</li>
        <li><strong>Acesso a Uma Rede de Mais de 100 Mil Empresas:</strong> Nosso banco de dados aberto permite que sua empresa seja encontrada por quem realmente importa: compradores, engenheiros, arquitetos, investidores e departamentos de compras de grandes empresas. Assim, você amplia suas possibilidades de negócios e aproximação de mercado.</li>
        <li><strong>Cotações Simplificadas e Ágeis:</strong> Com o PNI, você recebe cotações em apenas um clique e pode enviar solicitações por e-mail ou WhatsApp, facilitando negociações rápidas e eficientes. Essa facilidade reduz o tempo de fechamento de negócios, potencializando seus resultados.</li>
        <li><strong>Plataforma de Contato Direto e Eficiente:</strong> Nosso sistema permite que sua empresa apresente seus serviços, envie cotações e estabeleça contato direto com empresas em destaque, tudo de forma prática e acessível. Os canais de contato por e-mail e WhatsApp garantem uma comunicação mais próxima e efetiva.</li>
        <li><strong>Dados Abertos e Transparência:</strong> Nosso portal disponibiliza dados abertos para consulta, facilitando a pesquisa de fornecedores, produtos e serviços, promovendo maior transparência e confiabilidade nas negociações.</li>
        <li><strong>Apoio ao Desenvolvimento Nacional:</strong> Ao participar do PNI, sua empresa contribui para a geração de empregos, desenvolvimento econômico e fortalecimento do setor industrial brasileiro. Juntos, podemos impulsionar o crescimento do nosso país!</li>
      </ol>
      <p className="mt-4 font-medium">Empresas inovadoras como a KGS - Inteligência em Gestão de Manutenção já estão aproveitando as vantagens do PNI para expandir seus negócios e consolidar sua presença no mercado. Faça parte dessa transformação e destaque-se com inovação e eficiência!</p>
    </>
  );

  return (
    <SectionWrapper className="bg-gradient-to-br from-primary/5 via-sky-50 to-primary/10 py-12 md:py-20">
      <div className="container mx-auto max-w-4xl">
        <Dialog>
          <DialogTrigger asChild>
            <motion.div
              className="bg-white p-6 md:p-10 rounded-xl shadow-2xl border border-primary/30 cursor-pointer hover:shadow-primary/20 hover:border-primary transition-all duration-300 flex flex-col items-center"
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, ease: "easeOut" }}
            >
              <img src="https://storage.googleapis.com/hostinger-horizons-assets-prod/7040f89c-9a6d-458f-a45c-cf1bfcbf8dc8/56d795a0683051638e6747b9b08b5dce.png" alt="PNI - Portal Nacional da Indústria Logo" className="max-h-20 md:max-h-28 object-contain" />
              <Button variant="link" className="mt-4 text-primary hover:text-primary/80">
                <Info size={16} className="mr-2" /> Saiba mais sobre nossa parceria com o PNI
              </Button>
            </motion.div>
          </DialogTrigger>
          <DialogContent className="max-w-3xl bg-white p-6 md:p-8 max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-2xl md:text-3xl font-bold text-primary mb-4 flex items-center">
                <img src={pniLogoUrl} alt="PNI Logo" className="h-10 mr-3" />
                PNI - Portal Nacional da Indústria
              </DialogTitle>
            </DialogHeader>
            <DialogDescription className="mt-2 text-gray-700 space-y-4 text-sm md:text-base">
              <PniDetailedContent />
              <div className="mt-6 pt-4 border-t">
                <Button asChild variant="outline" className="border-primary text-primary hover:bg-primary/10">
                  <a href="https://www.portalnacionaldaindustria.com.br/" target="_blank" rel="noopener noreferrer">
                    Visite o Portal <ExternalLink size={16} className="ml-2" />
                  </a>
                </Button>
              </div>
            </DialogDescription>
          </DialogContent>
        </Dialog>
      </div>
    </SectionWrapper>
  );
};

export default KgsPniHighlightSection;
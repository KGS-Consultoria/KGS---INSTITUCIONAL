
import React from 'react';

const Footer = () => (
  <footer className="bg-slate-800 text-slate-300 py-8 text-center">
    <div className="container mx-auto">
      <p>&copy; {new Date().getFullYear()} KGS Consultoria. Todos os direitos reservados.</p>
      <p className="text-sm mt-2">A Manutenção Inteligente que Transforma Resultados.</p>
    </div>
  </footer>
);

export default Footer;

import React from 'react';
import SectionWrapper from './SectionWrapper';
import SectionTitle from './SectionTitle';
import { BarChart3, TrendingUp, Zap, PackageOpen, Users } from 'lucide-react';

const ResultCard = ({ icon, value, label, description, className = '' }) => (
  <div className={`bg-card p-6 rounded-lg shadow-md border border-border text-center ${className}`}>
    {icon}
    <p className="text-4xl font-bold gradient-text mt-2">{value}</p>
    <h3 className="text-xl font-semibold mt-2 mb-1 text-primary">{label}</h3>
    <p className="text-muted-foreground text-sm">{description}</p>
  </div>
);

const ResultsSection = () => (
  <SectionWrapper className="bg-secondary py-12 md:py-20">
    <div className="container mx-auto max-w-5xl">
      <SectionTitle>Resultados Que Falam Por Si</SectionTitle>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        <ResultCard
          icon={<BarChart3 size={40} className="text-primary mx-auto" />}
          value="42%"
          label="Redução nas paradas"
          description="Em falhas, alcançada em até 3 meses de projeto."
        />
        <ResultCard
          icon={<TrendingUp size={40} className="text-primary mx-auto" />}
          value="100%"
          label="Planos padronizados"
          description="E validados, garantindo consistência e eficiência."
        />
        <ResultCard
          icon={<Zap size={40} className="text-primary mx-auto" />}
          value="20%"
          label="Economia de energia"
          description="Média em processos críticos, otimizando o consumo."
        />
        <ResultCard
          icon={<PackageOpen size={40} className="text-primary mx-auto" />}
          value="50%"
          label="Redução em estoques"
          description="Desnecessários, liberando capital e espaço."
        />
        <ResultCard
          icon={<Users size={40} className="text-primary mx-auto" />}
          value="Proativas"
          label="Equipes engajadas"
          description="Mais técnicas, engajadas e com foco em resultados."
        />
         <div className="md:col-span-2 lg:col-span-1 flex justify-center items-center">
           <img  alt="Gráfico de resultados KGS" className="rounded-lg shadow-lg object-contain h-auto w-full max-w-xs" src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8ZGFzaGJvYXJkfGVufDB8fDB8fHww&auto=format&fit=crop&w=800&q=60" />
        </div>
      </div>
      <p className="text-center mt-10 text-muted-foreground">
        Os resultados apresentados são baseados em casos reais e podem variar conforme o escopo e características de cada projeto.
      </p>
    </div>
  </SectionWrapper>
);

export default ResultsSection;
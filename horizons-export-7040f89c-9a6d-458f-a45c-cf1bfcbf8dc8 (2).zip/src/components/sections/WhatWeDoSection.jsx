
import React from 'react';
import SectionWrapper from './SectionWrapper';
import SectionTitle from './SectionTitle';
import Card from './Card';
import { Wrench as Tool, Cpu, Users } from 'lucide-react';

const WhatWeDoSection = () => (
  <SectionWrapper className="bg-background py-12 md:py-20">
    <div className="container mx-auto max-w-5xl">
      <SectionTitle>O Que Fazemos na Prática</SectionTitle>
      <div className="grid md:grid-cols-3 gap-8">
        <Card
          icon={<Tool size={40} />}
          title="Gestão de manutenção e execução assistida"
          items={[
            "TPM e manutenção autônoma",
            "Organização técnica e visual",
            "PCM com planejamento e controle",
            "Implantação de metas e indicadores",
            "Gestão de lubrificação e energia",
            "Auditorias técnicas periódicas"
          ]}
          className="h-full"
        />
        <Card
          icon={<Cpu size={40} />}
          title="Tecnologia e IA aplicada à manutenção"
          items={[
            "CMS KGS gratuito e funcional",
            "Monitoramento acústico sem contato",
            "Classificação de ativos com IA",
            "Relatórios e insights para decisões rápidas",
            "Integração com estoques e operação"
          ]}
          className="h-full"
        />
        <Card
          icon={<Users size={40} />}
          title="Desenvolvimento técnico e liderança"
          items={[
            "Treinamentos com certificação",
            "Materiais operacionais prontos para uso",
            "Formação de líderes e multiplicadores",
            "Cultura de melhoria contínua na prática"
          ]}
          className="h-full"
        />
      </div>
    </div>
  </SectionWrapper>
);

export default WhatWeDoSection;
import React from 'react';
import SectionWrapper from './SectionWrapper';
import SectionTitle from './SectionTitle';
import { Rocket, Brain, Zap, Link as LinkIcon } from 'lucide-react';

const PartnerCard = ({ children, name, description, icon, href, bgColor = 'bg-card' }) => (
  <a
    href={href}
    target="_blank"
    rel="noopener noreferrer"
    className={`flex flex-col items-center text-center p-6 rounded-lg shadow-md border border-border ${bgColor} transition-all duration-300 hover:shadow-xl h-full group`}
  >
    <div className="h-20 mb-4 flex items-center justify-center">
      {children ? children : <div className="p-3 bg-primary/10 rounded-full text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors duration-300">{icon}</div>}
    </div>
    <h3 className="text-lg font-semibold mb-1 text-primary group-hover:text-primary-dark transition-colors duration-300">{name}</h3>
    <p className="text-sm text-muted-foreground flex-grow">{description}</p>
  </a>
);

const PartnershipsSection = ({ kgsOwnLogo }) => {
  const partnersData = [
    { 
      name: "Portal Nacional da Indústria (PNI)", 
      description: "Conexão com inovação e transformação digital.",
      logoUrl: "https://storage.googleapis.com/hostinger-horizons-assets-prod/7040f89c-9a6d-458f-a45c-cf1bfcbf8dc8/29505cc3bf1f6e4026966b00924763ed.jpg", /* User Provided Image */
      href: "https://www.portalnacionaldaindustria.com.br/",
      icon: <Rocket size={32} />
    },
    { 
      name: "Ploomes CRM", 
      description: "Integração com gestão comercial e técnica.",
      logoUrl: "https://storage.googleapis.com/hostinger-horizons-assets-prod/7040f89c-9a6d-458f-a45c-cf1bfcbf8dc8/00689e690bfef440c920f350d97d0cc2.jpg", /* User Provided Image */
      href: "https://www.ploomes.com/",
      icon: <Brain size={32} />
    },
    { 
      name: "ECOMETRIC", 
      description: "Sensores acústicos com IA para manutenção preditiva.",
      logoUrl: "https://storage.googleapis.com/hostinger-horizons-assets-prod/7040f89c-9a6d-458f-a45c-cf1bfcbf8dc8/bd295fee24ab614c21f9b75ad4416b88.jpg", /* User Provided Image */
      href: "https://www.ecometric.com.br/",
      icon: <Zap size={32} />
    },
    { 
      name: "Sistema CMS KGS", 
      description: "Desenvolvido pela KGS, gratuito e pronto para uso.",
      logoUrl: kgsOwnLogo,
      href: "#contato", // Example: link to contact section or specific CMS page
      icon: <LinkIcon size={32} />
    },
  ];

  return (
    <SectionWrapper className="bg-background py-12 md:py-20">
      <div className="container mx-auto max-w-5xl">
        <SectionTitle>Parcerias Que Impulsionam Sua Indústria</SectionTitle>
        <p className="text-center text-lg text-foreground mb-12 max-w-3xl mx-auto leading-relaxed">
          A KGS trabalha em sinergia com plataformas, tecnologias e soluções que potencializam ainda mais os resultados dos nossos clientes:
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {partnersData.map((partner) => (
            <PartnerCard 
              key={partner.name}
              name={partner.name} 
              description={partner.description}
              icon={partner.icon}
              href={partner.href}
            >
              <img alt={`${partner.name} Logo`} src={partner.logoUrl} className="max-h-16 object-contain filter grayscale group-hover:filter-none transition-all duration-300" />
            </PartnerCard>
          ))}
        </div>
      </div>
    </SectionWrapper>
  );
};

export default PartnershipsSection;
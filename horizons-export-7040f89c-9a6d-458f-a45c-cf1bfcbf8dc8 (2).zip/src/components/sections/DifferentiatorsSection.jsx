
import React from 'react';
import SectionWrapper from './SectionWrapper';
import SectionTitle from './SectionTitle';
import Card from './Card';
import { Cpu, DownloadCloud, Users, CheckCircle, TrendingUp, ShieldCheck, Wrench as Tool } from 'lucide-react';

const DifferentiatorsSection = () => (
  <SectionWrapper className="bg-secondary py-12 md:py-20">
    <div className="container mx-auto max-w-5xl">
      <SectionTitle>Nossos Diferenciais</SectionTitle>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        <Card
          icon={<DownloadCloud size={32} className="text-green-500" />}
          title="CMS gratuito e exclusivo"
          description="Nosso Sistema de Gestão de Manutenção (CMS) é prático, 100% gratuito e desenvolvido para facilitar a vida da operação. Permite o controle de planos, ordens de serviço, indicadores, históricos e muito mais."
        />
        <Card
          icon={<Cpu size={32} className="text-blue-500" />}
          title="Tecnologia com IA na prática"
          description="Aplicamos inteligência artificial para análise de falhas, monitoramento acústico preditivo e classificação automática de ativos críticos. Sua manutenção deixa de ser corretiva para se tornar estratégica."
        />
        <Card
          icon={<Users size={32} className="text-orange-500" />}
          title="Execução presencial e treinamentos inclusos"
          description="Acompanhamos seu time na prática. Nossos projetos incluem treinamentos certificados, suporte técnico e guias personalizados desde o primeiro dia."
        />
        <Card
          icon={<TrendingUp size={32} className="text-teal-500" />}
          title="Resultados em até 90 dias"
          description="Redução de até 30% nos custos de manutenção, aumento de 40% na disponibilidade de ativos, economia de até 25% em energia elétrica. Menos retrabalho, desperdícios e gargalos."
        />
         <Card
          icon={<ShieldCheck size={32} className="text-indigo-500" />}
          title="Soluções completas com visão de futuro"
          description="Implantamos TPM, manutenção autônoma, gestão de lubrificação, controle de energia, auditorias técnicas, 5S e PCM, integrando tudo com cultura operacional e indicadores."
        />
        <div className="md:col-span-2 lg:col-span-1 lg:col-start-2 flex items-center justify-center">
          <img  alt="Factory insights with AI" className="rounded-lg shadow-lg object-cover h-auto w-full max-w-sm" src="https://images.unsplash.com/photo-1557804506-669a67965ba0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aW5kdXN0cnklMjBtYWludGVuYW5jZXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=800&q=60" />
        </div>
      </div>
    </div>
  </SectionWrapper>
);

export default DifferentiatorsSection;
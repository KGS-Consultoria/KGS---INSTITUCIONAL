
import React from 'react';
import SectionWrapper from './SectionWrapper';
import SectionTitle from './SectionTitle';

const AboutUsSection = () => (
  <SectionWrapper className="bg-background py-12 md:py-20">
    <div className="container mx-auto max-w-3xl text-center">
      <SectionTitle>Quem Somos</SectionTitle>
      <p className="text-lg text-foreground mb-6 leading-relaxed">
        A KGS Consultoria é referência em gestão inteligente de manutenção industrial. Atendemos pequenas e médias indústrias, PCHs, subestações e redes de energia que desejam sair do improviso e entrar na era da performance com tecnologia, dados e ação em campo.
      </p>
      <p className="text-lg text-foreground mb-6 leading-relaxed">
        Somos especialistas em implantar e executar manutenção de forma estratégica, utilizando inteligência artificial, sistemas gratuitos e acompanhamento técnico direto no chão de fábrica. Atuamos onde realmente importa: no dia a dia da operação, reorganizando processos, otimizando ativos e entregando resultados comprovados.
      </p>
      <p className="text-lg text-foreground mb-6 leading-relaxed">
        Com nossa abordagem prática, conectada e de alto desempenho, transformamos rotinas operacionais em indicadores de sucesso.
      </p>
      <p className="text-xl font-semibold text-primary">
        KGS – Quando a manutenção é inteligente, os resultados são inevitáveis.
      </p>
    </div>
  </SectionWrapper>
);

export default AboutUsSection;
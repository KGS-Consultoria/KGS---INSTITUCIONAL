import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Instagram, Linkedin, Globe } from 'lucide-react';

const KgsHeroSection = ({ logoUrl }) => {
  const heroBackgroundImage = "https://storage.googleapis.com/hostinger-horizons-assets-prod/7040f89c-9a6d-458f-a45c-cf1bfcbf8dc8/aac60fcd03a0d0451e8e543171ef6c4f.png"; 

  return (
    <section 
      className="min-h-screen flex flex-col justify-center items-center text-center relative overflow-hidden bg-cover bg-center"
      style={{ backgroundImage: `url('${heroBackgroundImage}')` }}
    >
      <div className="absolute inset-0 bg-gradient-to-br from-primary-dark/70 via-primary-dark/60 to-black/70"></div>
      
      <motion.div
        className="relative z-10 p-6 md:p-10 max-w-3xl"
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.9, ease: "easeOut" }}
      >
        <p className="text-lg md:text-xl text-gray-100 mb-10 max-w-xl mx-auto shadow-text mt-12 sm:mt-16 md:mt-20">
          Transformamos manutenção em performance com inteligência, tecnologia e ação em campo.
        </p>
        
        <motion.div 
          className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
        >
          <Button 
            size="lg" 
            className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold px-8 py-3 rounded-lg shadow-lg transition-transform duration-300 hover:scale-105 w-full sm:w-auto"
            asChild
          >
            <a href="#contato">Fale Conosco</a>
          </Button>
          <div className="flex space-x-3">
            <Button 
              variant="outline" 
              size="icon" 
              className="text-gray-100 border-gray-200/70 hover:bg-white/20 hover:text-white rounded-full transition-all duration-300 hover:scale-110 focus:ring-2 focus:ring-gray-200"
              asChild
            >
              <a href="https://www.instagram.com/kgs_manutencao?igsh=MWtnZmQ4dHIwcm5scA%3D%3D&utm_source=qr" target="_blank" rel="noopener noreferrer" aria-label="Instagram KGS">
                <Instagram size={22} />
              </a>
            </Button>
            <Button 
              variant="outline" 
              size="icon" 
              className="text-gray-100 border-gray-200/70 hover:bg-white/20 hover:text-white rounded-full transition-all duration-300 hover:scale-110 focus:ring-2 focus:ring-gray-200"
              asChild
            >
              <a href="https://www.linkedin.com/company/kgs-inteligência-em-gestão-de-manutenção/" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn KGS">
                <Linkedin size={22} />
              </a>
            </Button>
            <Button 
              variant="outline" 
              size="icon" 
              className="text-gray-100 border-gray-200/70 hover:bg-white/20 hover:text-white rounded-full transition-all duration-300 hover:scale-110 focus:ring-2 focus:ring-gray-200"
              asChild
            >
              <a href="https://kgsmanutencao.com.br/" target="_blank" rel="noopener noreferrer" aria-label="Site KGS">
                <Globe size={22} />
              </a>
            </Button>
          </div>
        </motion.div>
      </motion.div>

      <div className="absolute bottom-0 left-0 w-full h-20" style={{background: 'linear-gradient(to top, rgba(15, 23, 42, 0.6), transparent)'}}></div>
      
      <motion.div 
        className="absolute top-5 left-5 w-16 h-16 md:w-24 md:h-24 bg-primary/30 rounded-full animate-pulse-slow"
        initial={{ scale:0, opacity:0}} animate={{scale:1, opacity:1}} transition={{delay:1, duration:1}}
      ></motion.div>
      <motion.div 
        className="absolute bottom-10 right-10 w-12 h-12 md:w-20 md:h-20 border-4 border-primary/40 rounded-xl animate-spin-slow"
        initial={{ rotate:0, opacity:0}} animate={{rotate:360, opacity:1}} transition={{delay:1.2, duration:15, repeat: Infinity, ease:"linear"}}
      ></motion.div>
       <motion.div 
        className="absolute top-1/4 right-1/4 w-8 h-8 bg-sky-400/30 rounded-full animate-ping"
        initial={{ opacity:0}} animate={{ opacity:1}} transition={{delay:1.5, duration:1}}
      ></motion.div>
    </section>
  );
};

export default KgsHeroSection;